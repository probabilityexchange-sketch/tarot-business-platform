Kali Meister zodiac collection — vector artwork
23 SVG files: plum and ivory for eleven signs, plum for Taurus.
Printify drafts are unpublished. Physical samples and final pricing review remain.
Website images are design concepts, not final manufacturer photographs.
